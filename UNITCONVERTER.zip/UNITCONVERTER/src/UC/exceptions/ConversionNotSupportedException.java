package UC.exceptions;

//Conversion not supported - when two units can't be converted
public class ConversionNotSupportedException extends Exception {
public ConversionNotSupportedException(String message) {
 super(message);
}
}
