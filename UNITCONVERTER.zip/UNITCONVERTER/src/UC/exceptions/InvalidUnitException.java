package UC.exceptions;

	//Invalid unit exception - when user enters wrong unit
	public class InvalidUnitException extends Exception {
	public InvalidUnitException(String message) {
	   super(message);
	}
	}
	