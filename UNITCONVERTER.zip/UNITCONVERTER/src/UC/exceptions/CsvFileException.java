package UC.exceptions;

public class CsvFileException extends Exception {
	public CsvFileException(String message) {
		   super(message);
		}
}