package UC.main;

import UC.utility.CsvUtils;              
import UC.exceptions.*;                  
import java.util.*;                      

public class UC {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        char G;                  
        do {
            try {
                //CATEGORIES
                System.out.println("\n========== UNIT CONVERTER ==========");

                List<String> categories = CsvUtils.loadCategories("categories.csv");

                // Display category options with numbers
                System.out.println("Select Category:");
                for (int i = 0; i < categories.size(); i++) {
                    System.out.println((i + 1) + ". " + categories.get(i));
                }

                // Asking user to choose a category by number
                System.out.print("Enter choice (1-" + categories.size() + "): ");
                int categoryIndex = sc.nextInt();         
                String selectedCategory = categories.get(categoryIndex - 1); 
                // -1 because list index starts from 0

                System.out.println(" Selected Category: " + selectedCategory);

                // SHOWING FROM UNITS
                List<String> units = CsvUtils.loadUnitsByCategory( "units_by_category.csv", selectedCategory );

                System.out.println("\nSelect FROM Unit to convert:");
                for (int i = 0; i < units.size(); i++) {
                    System.out.println((i + 1) + ". " + units.get(i));
                }

                // Asking user to choose FROM unit
                System.out.print("Enter choice (1-" + units.size() + "): ");
                int fromIndex = sc.nextInt();
                String fromUnit = units.get(fromIndex - 1);
                System.out.println("FROM Unit: " + fromUnit);

                //  SHOWING AVAILBLE "TO" UNITS to CONVERT
                System.out.println("\nSelect TO Unit:");
                for (int i = 0; i < units.size(); i++) {
                    System.out.println((i + 1) + ". " + units.get(i));
                }

                // AskING user to choose TO unit
                System.out.print("Enter choice (1-" + units.size() + "): ");
                int toIndex = sc.nextInt();
                String toUnit = units.get(toIndex - 1);
                System.out.println("TO Unit: " + toUnit);

                //  READING VALUE TO CONVERT
                System.out.print("\nEnter value to convert: ");
                double value = sc.nextDouble();
                
                double factor = CsvUtils.getConversionFactor("unit_converter.csv",  fromUnit,toUnit);

                double result = value * factor;

              System.out.println("\n========== RESULT ==========");
                System.out.println(value + " " + fromUnit + " = " + result + " " + toUnit);
                  System.out.println("============================");
               // SAVING HISTORY 
                  CsvUtils.saveHistory( "conversion_history.csv",value,fromUnit,toUnit, result);
                    System.out.println("Conversion saved to history!");
               
            } catch (InputMismatchException e) {
             
                System.out.println(" Error: Please enter a valid number!");
                  sc.nextLine();

            } catch (CsvFileException e) {

                System.out.println(" File Error: " + e.getMessage());

            } catch (ConversionNotSupportedException e) {
                System.out.println(" Conversion Error: " + e.getMessage());

            } catch (Exception e) {
                System.out.println(" Error: " + e.getMessage());
            }

            System.out.println("\n------------------------------");
            System.out.print("Do you want to continue? (y/n): ");
            G = sc.next().charAt(0);

        } while (G == 'y' || G == 'Y');
        System.out.println("\nThank you for using Unit Converter!");
        sc.close();
    }
}
