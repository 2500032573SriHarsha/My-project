package UC.utility;

import java.io.*;
import java.util.*;
import java.text.SimpleDateFormat;
import UC.exceptions.*;

public class CsvUtils {
    // ============ 1: Loading categories ============
    public static List<String> loadCategories(String csvFile) throws IOException, CsvFileException {
        List<String> categories = new ArrayList<>();
        
        File file = new File(csvFile);
        if (!file.exists()) {
            throw new CsvFileException("File not found: " + csvFile);
        }
        
        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            String line;
            boolean isFirstLine = true;
            
            while ((line = br.readLine()) != null) {
                if (isFirstLine) {
                    isFirstLine = false;
                    continue; // Skip header
                }
                
                String[] parts = line.split(",");
                if (parts.length >= 2) {
                    String categoryName = parts[1].trim();
                    categories.add(categoryName);
                }
            }
        }
        return categories;
    }
    
    // ============  Loading units by category ============
    public static List<String> loadUnitsByCategory(String csvFile, String category) 
            throws IOException, CsvFileException {
        List<String> units = new ArrayList<>();
        
        File file = new File(csvFile);
        if (!file.exists()) {
            throw new CsvFileException("File not found: " + csvFile);
        }
        
        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            String line;
            boolean isFirstLine = true;
            
            while ((line = br.readLine()) != null) {
                if (isFirstLine) {
                    isFirstLine = false;
                    continue;
                }
                
                String[] parts = line.split(",");
                if (parts.length >= 3 && parts[1].trim().equalsIgnoreCase(category)) {
                    units.add(parts[2].trim());
                }
            }
        }
        return units;
    }
    
    // ============ Get conversion factor 
    public static double getConversionFactor(String csvFile, String fromUnit, String toUnit) 
            throws IOException, ConversionNotSupportedException, CsvFileException {
        
        File file = new File(csvFile);
        if (!file.exists()) {
            throw new CsvFileException("File not found: " + csvFile);
        }
        
        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            String line;
            boolean isFirstLine = true;
            
            while ((line = br.readLine()) != null) {
                if (isFirstLine) {
                    isFirstLine = false;
                    continue;
                }
                
                String[] parts = line.split(",");
                if (parts[0].trim().equalsIgnoreCase(fromUnit) &&
                	    parts[1].trim().equalsIgnoreCase(toUnit)) {
                	    return Double.parseDouble(parts[3].trim());
                	}

            }
        }
        
        throw new ConversionNotSupportedException(
            "Cannot convert " + fromUnit + " to " + toUnit);
    }
    
    //history
    public static void saveHistory(String csvFile, double fromValue, String fromUnit, 
            String toUnit, double result) 
throws IOException, CsvFileException {
try {
boolean fileExists = new File(csvFile).exists();

try (FileWriter fw = new FileWriter(csvFile, true);
BufferedWriter bw = new BufferedWriter(fw)) {

if (!fileExists) {
bw.write("FromValue,FromUnit,ToUnit,Result,DateTime\n");
}

String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
bw.write(fromValue + "," + fromUnit + "," + toUnit + "," + result + "," + timestamp + "\n");
}
} catch (IOException e) {
throw new CsvFileException(" Error saving history: " + e.getMessage());
}
}
}
